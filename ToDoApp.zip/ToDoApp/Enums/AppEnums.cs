﻿namespace ToDoApp.Enums
{
    public enum ToDoItemType { All, Upcoming, Completed, Expired }
}
