﻿namespace ToDoApp.Dtos
{
    public class ToDoItemCreateDto : ToDoItemBaseDto
    {
    }
}
